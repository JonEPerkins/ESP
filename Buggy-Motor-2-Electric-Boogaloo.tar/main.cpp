#include "mbed.h"
#include "QEI.h"
#include "C12832.h" 


DigitalOut enable(PB_4);
DigitalOut bipolar1(PB_3);
PwmOut mot1pwm(PC_8);
C12832 lcd(D11, D13, D12, D7, D10); 


QEI wheel (PB_10, PA_8, NC ,512);
//QEI (PinName channelA, PinName channelB, PinName index, int pulsesPerRev, Encoding encoding=X2_ENCODING)

int main() {
    enable = 1;
    bipolar1 = 1;
    mot1pwm.period(0.001f);
    mot1pwm.write(0.1f);

    wait(2);
    mot1pwm.write(0.5f);
    wait(2);

    mot1pwm.write(0.9f);

    lcd.printf("Pulses is: %i\n", wheel.getPulses());


    while(1){};
}
